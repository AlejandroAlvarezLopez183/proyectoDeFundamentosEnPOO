package examen1;

public class inicio {

	public static void main(String[] args) {
		pedir.PedirNumero();
	}

}
