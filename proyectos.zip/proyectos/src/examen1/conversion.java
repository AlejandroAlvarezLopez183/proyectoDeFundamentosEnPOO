package examen1;
import java.util.Arrays;

public class conversion {
public static String convertir(String numero) {
	int numeroDe = Integer.parseInt(numero,2);
	String hexagecima = Integer.toHexString(numeroDe).toUpperCase();
	return hexagecima;
}
}
