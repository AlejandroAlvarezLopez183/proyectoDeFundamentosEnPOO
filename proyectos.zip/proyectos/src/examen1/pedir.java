package examen1;
import java.util.Scanner;
public class pedir {
	
public static void PedirNumero() {
	Scanner guardar = new Scanner(System.in);
	System.out.println("Ingrese un numero en binario: ");
	String numero = guardar.nextLine();
    String hexa = conversion.convertir(numero);
	System.out.println("hexagesimal : "+hexa);
	}
}
