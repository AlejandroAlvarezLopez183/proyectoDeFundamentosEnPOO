/**
 * 
 */
/**
 * 
 */
module proyectos {
	requires java.desktop;
	requires jdk.httpserver;
	requires java.sql;
	requires webcam.capture;
	requires com.google.zxing.javase;
	requires com.google.zxing;
	requires spark.core;
}