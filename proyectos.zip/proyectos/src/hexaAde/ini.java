package hexaAde;

public class ini {

	public static void main(String[] args) {
	pedir1.perdirnumerohexa();
	}

}
