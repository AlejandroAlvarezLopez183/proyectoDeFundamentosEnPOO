package hexaAde;

public class convertirde {
public static int convertirdecimal(String numero) {
    int decimal = 0;
    
   
    for (int i = 0; i < numero.length(); i++) {
        char hexChar = numero.charAt(i);
        
        int  valorDecimal;
        if (hexChar >= '0' && hexChar <= '9') {
           valorDecimal = hexChar - '0';
        } else if (hexChar >= 'A' && hexChar <= 'F') {
            valorDecimal = 10 + (hexChar - 'A');
        } else if (hexChar >= 'a' && hexChar <= 'f') {
            valorDecimal = 10 + (hexChar - 'a');
        } else {
            System.out.println("El numero ingresado no es un valor hexadecimal valido.");
            return -1; 
        } decimal = decimal * 16 + valorDecimal;
    }
    
    return decimal;}
}
