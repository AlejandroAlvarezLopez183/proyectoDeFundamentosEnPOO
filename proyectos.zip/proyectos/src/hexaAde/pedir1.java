package hexaAde;
import java.util.Scanner;
public class pedir1 {
public static void perdirnumerohexa() {
	Scanner guardar = new Scanner(System.in);
	System.out.println("Ingrese un numero en hexagesimal: ");
	String numero = guardar.nextLine();
	
	System.out.println("El numero convertido es: "+convertirde.convertirdecimal(numero));
}
}
