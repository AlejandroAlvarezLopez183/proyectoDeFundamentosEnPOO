package proyectos1;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class jhj {

	public static void main(String[] args) {
		  try {
	            InetAddress inetAddress = InetAddress.getLocalHost();
	            String ipAddress = inetAddress.getHostAddress();
	            System.out.println("IP local: " + ipAddress);
	        } catch (UnknownHostException e) {
	            System.err.println("No se pudo obtener la IP local.");
	            e.printStackTrace();
	        }
	}

}
