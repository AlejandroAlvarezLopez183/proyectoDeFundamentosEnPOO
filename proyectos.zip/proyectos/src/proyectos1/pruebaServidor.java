package proyectos1;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class pruebaServidor {

    private static final Map<String, LocalDateTime> registros = new ConcurrentHashMap<>();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(5000), 0);
        server.createContext("/reportar_estado", new EstadoHandler());
        server.setExecutor(null);  // Usa un executor por defecto
        server.start();
        System.out.println("Servidor escuchando en el puerto 5000...");

        // Tarea para verificar el estado de las computadoras cada minuto
        new Thread(() -> {
            while (true) {
                verificarEstados();
                try {
                    Thread.sleep(60000);  // Verificar cada 60 segundos
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }

    static class EstadoHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                String query = new String(exchange.getRequestBody().readAllBytes());
                String nombrePc = query.split("&")[1].split("=")[1];
                registros.put(nombrePc, LocalDateTime.now());

                String response = "Estado registrado para " + nombrePc;
                exchange.sendResponseHeaders(200, response.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response.getBytes());
                }
            }
        }
    }

    private static void verificarEstados() {
        LocalDateTime ahora = LocalDateTime.now();
        registros.forEach((pc, ultimaVez) -> {
            if (ahora.isAfter(ultimaVez.plusMinutes(2))) {
                System.out.println("Alerta: La PC " + pc + " parece estar apagada o fuera de línea.");
            }
        });
    }

}
